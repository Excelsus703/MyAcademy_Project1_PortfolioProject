---
name: Slate Horizon
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#1e293b'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#94a3b8'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8e9192'
  outline-variant: '#3f465c'
  surface-tint: '#c6c6c7'
  primary: '#ffffff'
  on-primary: '#2f3131'
  primary-container: '#e2e2e2'
  on-primary-container: '#636565'
  inverse-primary: '#5d5f5f'
  secondary: '#b9c8de'
  on-secondary: '#233143'
  secondary-container: '#39485a'
  on-secondary-container: '#a7b6cc'
  tertiary: '#ffffff'
  on-tertiary: '#1000a9'
  tertiary-container: '#e1e0ff'
  on-tertiary-container: '#4f51dd'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c7'
  on-primary-fixed: '#1a1c1c'
  on-primary-fixed-variant: '#454747'
  secondary-fixed: '#d4e4fa'
  secondary-fixed-dim: '#b9c8de'
  on-secondary-fixed: '#0d1c2d'
  on-secondary-fixed-variant: '#39485a'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
  brand-blue: '#6366f1'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  gutter: 24px
  xl: 32px
  xxl: 48px
  container-max: 1280px
---

## Brand & Style
The brand identity is "Slate Horizon"—a professional, high-security aesthetic designed for individual portfolio management and financial showcase. It blends **Corporate Modern** reliability with a subtle **Glassmorphism** touch to feel contemporary and premium. 

The visual language communicates "secure dashboarding" through a deep, nocturnal color palette and precise geometric shapes. The emotional response should be one of calm, focused control. It avoids the playfulness of consumer social apps in favor of a technical, developer-adjacent precision, utilizing high-quality typography and atmospheric background gradients to create a sense of infinite digital space.

## Colors
The palette is rooted in a deep "Midnight Slate" foundation. 
- **Primary ($ffffff):** Reserved for high-contrast text and critical iconography against dark backgrounds.
- **Secondary ($94a3b8):** A muted slate used for supporting text and non-interactive UI elements.
- **Tertiary/Brand ($6366f1):** An "Indigo Spark" used sparingly for calls-to-action, focus states, and decorative accents to signify importance and interactivity.
- **Neutral ($0f172a):** The core background color, providing the "dark mode" canvas.

Surface layering is achieved through tonal variations of slate (#131b2e and #1e293b), ensuring that even in a dark UI, the hierarchy remains legible through lightness contrast rather than saturated color.

## Typography
The system uses a dual-font strategy: **Hanken Grotesk** for headlines to provide a sharp, modern, and slightly geometric character, and **Inter** for all functional body and label text to ensure maximum legibility and a systematic feel.

- **Headlines:** Use heavy weights (700-800) with tight tracking to anchor the page.
- **Interactive Labels:** Utilize medium weights (500-600) to distinguish them from static body text.
- **Data/Security labels:** Often use `label-sm` with uppercase transformation and increased letter spacing to evoke a "technical" or "system-generated" feel.

## Layout & Spacing
The system follows an **8px grid** (with 4px micro-adjustments). 
- **Fixed-Width Container:** Core utility screens (like login) are centered with a max-width of 440px. Full dashboards should utilize a fluid 12-column grid with 24px gutters.
- **Vertical Rhythm:** A strict hierarchy of spacing is used: `xs` for label-to-input, `md` for between-field sets, and `xl` for card internal padding.
- **Mobile Adaptivity:** On mobile screens, `xxl` (48px) top padding is reduced to `xl` (32px), and the `gutter` (24px) side margins are maintained to prevent content from touching the edges of the device.

## Elevation & Depth
Depth is created through a combination of **Tonal Layering** and **Atmospheric Glassmorphism**:
- **Background:** A radial mesh gradient starting from `#1e293b` (top-left) to `#0f172a` (bottom-right) sets the base environment.
- **Surfaces:** Main containers use `surface-container-low` at 80% opacity with a `backdrop-filter: blur(12px)` to simulate frosted glass.
- **Outlines:** Instead of heavy shadows, depth is reinforced by a 1px border of `outline-variant` (#3f465c), which provides a crisp edge against the dark background.
- **Shadows:** Only used for floating cards and primary buttons. Use a dual-stack shadow: a wide, low-opacity ambient shadow (25px blur) and a tighter, tinted shadow for the primary color (indigo) to give the appearance of a light-emitting element.

## Shapes
The shape language is primarily **Soft (0.25rem - 0.75rem)** to maintain a professional profile without becoming too organic or "bubbly."
- **Standard UI (Buttons/Inputs):** Use `rounded-lg` (0.25rem - 0.5rem) for a precise, modern look.
- **Containers (Cards):** Use `rounded-xl` (0.75rem) to distinguish the main content area from the background.
- **Circular Elements:** Icons and avatars are fully rounded (`rounded-full`) to act as visual focal points.

## Components
- **Buttons:** Primary buttons use the `brand-blue` background with white text. They include a subtle 30% opacity border of their own color and a `shadow-lg` tinted with indigo. On hover, apply a slight scale-down (0.98) for tactile feedback.
- **Input Fields:** Backgrounds should be a darkened slate (`#020617` or `slate-900` at 50% opacity). Borders use `outline-variant`. On focus, transition to a `brand-blue` border with a 3px outer ring of `brand-blue/20`.
- **Iconography:** Use Material Symbols (Outlined). Icons within inputs are `on-surface-variant` and sized at 20px. Decorative brand icons should use a circular tinted background (10% brand-blue).
- **Checkboxes:** Small, 20x20px rounded squares with `brand-blue` fill and `brand-blue/20` focus rings.
- **Security Indicator:** A horizontal rule using `surface-container-highest` with centered text in `label-sm` style to indicate section transitions or metadata.