---
name: Ironclad Corporate
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fd'
  on-secondary-container: '#57657b'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00174b'
  on-tertiary-container: '#497cff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d5e3fd'
  secondary-fixed-dim: '#b9c7e0'
  on-secondary-fixed: '#0d1c2f'
  on-secondary-fixed-variant: '#3a485c'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style
The design system is engineered for high-stakes administrative environments where security, clarity, and professional rigor are paramount. The brand personality is authoritative yet unobtrusive, prioritizing functional efficiency over decorative flair. 

The aesthetic leans into **Corporate Modernism**, characterized by a strict adherence to grid systems, ample white space, and a refined "high-fidelity" feel. It evokes an emotional response of stability and trust through precision-engineered components, subtle transitions, and a focus on content hierarchy. This is a system built for users who require a robust, distraction-free interface to perform critical operations.

## Colors
The palette is rooted in deep slates and professional blues to signal security and "Enterprise" reliability. 

- **Primary (#0F172A):** A deep Navy-Slate used for headings, primary brand moments, and high-contrast text.
- **Secondary (#334155):** A muted Slate used for subtext and iconography.
- **Tertiary (#2563EB):** A vibrant "Action Blue" reserved strictly for primary calls to action, focus states, and success indicators.
- **Neutral (#F8FAFC):** A crisp, cool white used for backgrounds to maintain a clinical, clean environment.
- **Functional Colors:** Use a standard destructive Red (#DC2626) for errors and security alerts, ensuring high contrast against the neutral background.

## Typography
The system utilizes **Hanken Grotesk** for headlines to provide a sharp, contemporary edge that feels modern and engineered. **Inter** is utilized for all functional text, body copy, and labels due to its exceptional legibility in data-dense environments and high x-height.

Weight is used strategically to create hierarchy:
- **Bold (700):** Reserved for primary page titles.
- **Semi-Bold (600):** Used for section headers and primary button labels.
- **Medium (500):** Used for input labels and navigation items.
- **Regular (400):** Used for all body text and descriptive content.

## Layout & Spacing
The layout follows a strict **8px grid system** to ensure mathematical consistency across all components. 

- **Desktop:** A 12-column fluid grid with a maximum container width of 1280px. Centered login modules should span 4 columns (approx 400px) to maintain focus.
- **Margins:** Use 24px (lg) margins for mobile and 48px (xxl) for tablet/desktop to breathe air into the layout.
- **Reflow:** On mobile devices, the layout collapses into a single column with 16px horizontal gutters. All interactive targets must maintain a minimum height of 48px for touch accessibility.

## Elevation & Depth
Depth is conveyed through **Tonal Layering** and **Micro-Shadows**. Instead of heavy shadows, the system uses "Precision Elevations" to differentiate surfaces:

1.  **Level 0 (Base):** The neutral background (#F8FAFC).
2.  **Level 1 (Surface):** White containers (#FFFFFF) with a 1px border (#E2E8F0).
3.  **Level 2 (Raised):** Used for the login card. A very soft, highly diffused shadow (0px 4px 6px -1px rgba(0,0,0,0.1)) combined with a subtle border.
4.  **Level 3 (Overlay):** Used for modals or tooltips. A more pronounced shadow to indicate temporary interaction.

Avoid glassmorphism or heavy gradients. Depth should feel physical and structural, not decorative.

## Shapes
The shape language is **Soft (0.25rem/4px)**. This slight rounding provides a professional, "machined" appearance that feels approachable but remains serious. 

- **Inputs/Buttons:** Use a 4px corner radius.
- **Cards/Containers:** Use an 8px (rounded-lg) corner radius to differentiate larger structural blocks from smaller interactive elements.
- **Checkboxes:** A subtle 2px radius to avoid a "toy-like" circular appearance while softening the points.

## Components
- **Buttons:** Primary buttons use the Tertiary Blue (#2563EB) with white text. Hover states should darken the blue slightly. Secondary buttons use a transparent background with a 1px border in Slate-300.
- **Input Fields:** Use a 1px border (#CBD5E1). On focus, the border changes to Tertiary Blue with a 3px soft outer glow (ring) of the same color at 20% opacity.
- **Labels:** Always positioned above the input field in `label-md` weight. Requirement indicators (asterisks) should be Slate-400, not red, unless the field is in an error state.
- **Cards (Login):** The central login card should be white, using Level 2 elevation, with internal padding of 32px (xl) to create a sense of premium space.
- **Feedback:** Use "Toasts" or inline "Alerts" for login failures. These should be high-contrast: a soft red background with a dark red border and dark red text to ensure the message is unmistakable.
- **Checkboxes:** For "Remember Me" features, use a custom-styled checkbox that matches the 4px roundedness of the inputs, using the Tertiary Blue for the active state.